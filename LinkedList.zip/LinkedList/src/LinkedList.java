import java.util.Iterator;

public class LinkedList <E> implements Iterable<E>{

 private No inicio;
 private int capacidade;

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            No no_atual = inicio;
            @Override
            public boolean hasNext() {
                if(no_atual.prox_no != null){
                    return true;
                }
                return false;
            }

            @Override
            public E next() {
                no_atual = no_atual.prox_no;
                return no_atual.elemento;
            }
        };
    }

    private class No{

     public No(E elemento){
         this.elemento = elemento;
     }
     private E elemento;
     private No prox_no;
 }

    public void add(E element){
     if(inicio != null){
         No outro_no = new No(element);
        if(inicio.prox_no != null){
            No no_atual = inicio.prox_no;
            while(no_atual.prox_no != null){
                no_atual = no_atual.prox_no;
            }
            no_atual.prox_no = outro_no;
        } else {
            inicio.prox_no = outro_no;
        }

     }else{
         inicio = new No(element);
     }
     capacidade++;
}

    private No getNo(int index){
        if (index <= capacidade && index > -1) {
            int index_atual = 0;
            No atual_no = inicio;
            while (index >= index_atual){
                atual_no = atual_no.prox_no;
                index_atual++;
            }
            return atual_no;
        }
        return null;
    }

    public E get(int index){
     return getNo(index).elemento;
    }

    public void add(E element, int index){

     if (index <= capacidade && index > -1) {
         if (index == 0) {
             No new_no = new No(element);
             No no_salvo = inicio;
             inicio = new_no;
             new_no.prox_no = no_salvo;
         } else {
             No novo_no = new No(element);
             No no_anterior = getNo(index - 1);
             No nos_salvos = no_anterior.prox_no;
             no_anterior.prox_no = novo_no;
             novo_no.prox_no = nos_salvos;

         }
     }
     capacidade++;
    }

    public void remove(int index){
        if (index < capacidade && index > -1) {
            No no_anterior = getNo(index-1);
            no_anterior.prox_no = no_anterior.prox_no.prox_no;
        }
        capacidade--;
    }

    public void removeFirst(){
        inicio = inicio.prox_no;
        capacidade--;
    }

    public int contains(E element){
        int index = 0;
        No no_atual = inicio;
        while (no_atual != null){
            if (no_atual.elemento.equals(element)){
                return index;
            }else{
                no_atual = no_atual.prox_no;
                index++;
            }
        }
        return -1;
    }

    public void removeElement(E element){
        int index = contains(element);
        if(index != -1){
            remove(index);
        }
    }

    public int size(){
     return capacidade;
    }










}
